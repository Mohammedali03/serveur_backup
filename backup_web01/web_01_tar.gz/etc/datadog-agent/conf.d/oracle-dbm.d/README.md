
The configuration directory ``oracle-dbm.d`` is deprecated. Use ``oracle.d`` instead.
